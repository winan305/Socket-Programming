//-------------------------------------------------------------
// 파일명 : server.c
// 기  능 : 채팅 참가자(닉네임, 아이피, 접속시간) 관리
//          채팅내역(닉네임, 문자수, 문자내용, 발송시간) 관리
//          클라이언트가 송신한 메세지를 모든 클라이언트에 전송
//          클라이언트 접속/해제 시 모든 클라이언트에게 알림
//          커맨드를 통해 클라이언트 리스트 보기, 클라이언트 추방, 서버 종료 기능
// 컴파일 : gcc -o server server.c
// 사용법 : ./server [port]
//          ex) ./server 5123
//-------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <time.h>

// 버퍼의 최대 크기
#define MAXLINE  1000
// 데이터 저장 시 허용할 크기
#define LEN   30
// 소켓의 최대 개수. 솔라리스의 경우 64
#define MAX_SOCK 1024 

// 클라이언트의 정보를 저장할 구조체
struct Client {
	// 소켓번호, 아이피, 접속시간, 이름을 저장한다.
	int socketNumber;
	char ip[LEN];
	char connectTime[LEN];
	char name[LEN];
};

// 채팅 간 로그를 저장할 구조체
struct Log {
	// 메세지, 전송시간, 길이를 저장한다.
	char message[MAXLINE+LEN];
	char sendTime[LEN];
	int length;
};

char *EXIT_STRING = "exit";   // 클라이언트의 종료요청 문자열
char *START_STRING = "====== System : Welcome to chat server! ======\n"; // 클라이언트 환영 메시지
char *SHOW_CLIENTS = "-show"; // 클라이언트 내역 출력명령
char *DEPORT_CLIENTS = "-deport"; // 클라이언트 추방명령 (-deport)
char *HELP = "-help"; // 서버 명령어에 대한 도움말 명령
char *FINISH = "-finish"; // 서버 종료 명령
char *filename = "log.txt"; // 채팅 내역을 저장할 로그파일 이름
char buf[MAXLINE+1]; // 채팅 간 사용할 버퍼
int maxfdp1; // 최대 소켓번호 +1
int num_chat = 0; // 채팅 참가자 수
int listen_sock, accp_sock; // 서버의 리슨, 어셉트 소켓
time_t t; // 시간을 위한 시간 구조체
FILE *logFile; // 로그를 저장할 파일 포인터
struct Client clients[MAX_SOCK]; // 접속한 클라이언트들을 저장할 클라이언트 구조체 배열
int serverState = 1; // 서버 상태 변수. 1이면 가동중, 0이면 서버 종료.

void addClient(int s, struct sockaddr_in *newcliaddr, char* name); // 새로운 채팅 참가자 처리 함수
void removeClient(int s); // 채팅 탈퇴 처리 함수
int getmax(); // 최대 소켓 번호 찾기 함수

int tcp_listen(int host, int port, int backlog); // 소켓 생성 및 listen 함수
void errquit(char *mesg) { perror(mesg); exit(1); } // 에러발생시 처리하는 함수

char* getNowTime() { time(&t); return ctime(&t); } // 현재 시간을 문자열로 반환하는 함수
void send2clients(int num, char message[MAXLINE], int len); // 클라이언트들에게 메시지를 전송해주는 함수
void save(struct Log log); // 로그를 저장하는 함수
void printClients(); // 현재 클라이언트 내역을 출력하는 함수
void deport(int client); // clien(소켓번호)를 추방하는 함수)
void printHelp(); // -help 커맨드 입력 시 다른 커맨드들의 도움말 출력
void finish(); // 서버 종료 함수

int main(int argc, char *argv[]) {
	// 소켓 구조체
	struct sockaddr_in cliaddr;
	// 클라이언트의 이름을 저장할 버퍼
	char namebuf[LEN];
	// 반복문과 바이트수, 소켓구조체의 길이 저장 변수
	int i, j, nbyte, addrlen = sizeof(struct sockaddr_in);
	// 읽기를 감지할 fd_set 구조체
	fd_set read_fds;  
	// 로그를 저장할 로그 구조체
	struct Log log;
	// 로그를 저장해야 하는지, 클라이언트를 출력해야 하는지 결정할 플래그 변수
	int savelog = 0;
	// 추방을 원하는 소켓 번호 저장 변수
	int deportNumber = -1;

	// 사용법이 잘못되었을 경우 사용법 출력 후 종료
	if(argc != 2) {
		printf("Usage :./server [port]\n");
		exit(0);
	}

	// 서버가 올바르게 시작 시, 내용을 로그에 저장한다.
	// buf에 서버가 시작됨을 출력하는 메세지를 저장한 후 이를 로그로 저장한다.
	sprintf(buf, "[Server start] ");
	// 로그는 버퍼에 저장되어 있다. 길이를 구하고 개행문자를 없앤다.
	log.length = strlen(buf);
	buf[log.length-1] = 0;
	// 메세지의 내용과 전송시간을 로그에 저장한다.
	strcpy(log.message, buf);
	strcpy(log.sendTime, getNowTime());
	// 저장된 로그를 파일에 쓴다.
	save(log);
	printf("If you want to know command, Enter \"-help\" \n");
	// tcp_listen(host, port, backlog) 함수 호출
	// 클라이언트의 접속을 대기한다.
	listen_sock = tcp_listen(INADDR_ANY, atoi(argv[1]), MAX_SOCK);

	// 서버 종료하기 전 까지 무한반복한다.
	while(serverState) {
		// 1ead_fds의 모든 소켓을 0으로 초기화한다.
		FD_ZERO(&read_fds);
		// listen 소켓을 세팅한다.
		FD_SET(listen_sock, &read_fds);
		// 키보드 입력용 파일 디스크립터를 세팅한다.
		FD_SET(0, &read_fds);

		// 모든 클라이언트의 소켓들을 세팅한다.
		for(i=0; i<num_chat; i++)
			FD_SET(clients[i].socketNumber, &read_fds);

		// maxfdp1를 계산한다.
		maxfdp1 = getmax() + 1;     

		// 소켓들에서 발생하는 I/O 를 감지한다.
		if(select(maxfdp1, &read_fds,NULL,NULL,NULL)<0)
			errquit("select fail");

		// 키보드 입력이 세트되어 있으면 서버의 커맨드를 입력받는다.
		if (FD_ISSET(0, &read_fds)) {
			// buf에 서버의 커맨드를 입력받는다.
			if(fgets(buf, MAXLINE, stdin)) {
				// 커맨드에 대한 처리를 한다.
				// 커맨드 입력은 예외가 없다고 가정한다.
				if(strstr(buf, HELP)) printHelp();
				else if(strstr(buf, SHOW_CLIENTS) != NULL) printClients();
				else if(strstr(buf, DEPORT_CLIENTS) != NULL) {
					printf("Socket Number : ");
					// 추방할 클라이언트의 소켓 번호를 입력받고 클라이언트를 추방한다.
					scanf("%d", &deportNumber);
					deport(deportNumber);
					// 추방에 대한 로그를 저장한다.
					savelog = 1;
				}
				// 서버를 종료한다.
				else if(strstr(buf, FINISH) != NULL) {
					// 서버 종료에 대한 로그를 저장한다.
					savelog = 1;
					// 서버를 종료한다.
					finish();
				}
			}
		}

		// 리슨 소켓이 세트되어 있는 경우, 클라이언트가 접속을 요청한 것이다.
		if(FD_ISSET(listen_sock, &read_fds)) {
			// 클라이언트 접속시 로그를 저장한다.
			savelog = 1;

			// 접속을 accept한다.
			accp_sock=accept(listen_sock, (struct sockaddr*)&cliaddr, &addrlen);

			// 접속이 잘못되었을 경우 에러를 발생시킨다.
			if(accp_sock == -1)
				errquit("accept fail");

			// 클라이언트가 접속하게 되면 클라이언트의 닉네임을 받아온다.
			nbyte = recv(accp_sock, namebuf, LEN, 0);
			// 버퍼의 끝에 널을 삽입한다.
			namebuf[nbyte] = 0;
			// 클라이언트에 START_STRING을 보내어 접속되었음을 알린다.
			send(accp_sock, START_STRING, strlen(START_STRING), 0);
			// 클라이언트를 추가한다.
			addClient(accp_sock,&cliaddr, namebuf);
			// 새 클라이언트가 추가되었으므로 클라이언트의 내용을 갱신한다.
		}

		// 클라이언트가 보낸 메시지를 모든 클라이언트에게 방송
		for(i = 0; i < num_chat; i++) {
			// 클라이언트들의 소켓이 세팅되어 있는 경우
			if(FD_ISSET(clients[i].socketNumber, &read_fds)) {
				// 메세지가 방송되므로 로그를 저장한다.
				savelog = 1;
				// 클라이언트로부터 메세지를 받아온다.
				nbyte = recv(clients[i].socketNumber, buf, MAXLINE, 0);
				// nbyte가 0이거나 음수인 경우, 클라이언트의 종료로 판단한다.
				if(nbyte<= 0) {
					removeClient(i); // 클라이언트를 종료한다.
					// 클라이언트에 변화가 있으므로 로그를 저장한다.
					savelog = 1;
					continue;
				}
				// 버퍼의 마지막에 널을 삽입한다.
				buf[nbyte] = 0;

				// 클라이언트가 종료 문자열을 보내온 경우
				if(strstr(buf, EXIT_STRING) != NULL) {
					removeClient(i); // 클라이언트를 종료한다.
					// 클라이언트에 변화가 있으므로 로그를 저장한다.
					savelog = 1;
					continue;
				}

				// 모든 채팅 참가자에게 메시지를 방송한다.
				send2clients(num_chat, buf, nbyte);
			}
		}
		// 로그저장 플래그가 참(1)인 경우
		if(savelog) {
			// 로그는 버퍼에 저장되어 있다. 길이를 구하고 개행문자를 없앤다.
			log.length = strlen(buf);
			buf[log.length-1] = 0;
			// 메세지의 내용과 전송시간을 로그에 저장한다.
			strcpy(log.message, buf);
			strcpy(log.sendTime, getNowTime());
			// 저장된 로그를 파일에 쓴다.
			save(log);
			// 로그 플래그를 0으로 바꿔준다.
			savelog = 0;
		}
	}  // end of while
	return 0;
}

// num만큼의 클라이언트들에게 len만큼의 message를 방송하는 함수
void send2clients(int num, char message[MAXLINE], int len) {
	int i;
	for (i = 0; i < num; i++)
		// 클라이언트들의 소켓에 전송한다.
		send(clients[i].socketNumber, message, len, 0);
}
// 새로운 채팅 참가자 처리
void addClient(int s, struct sockaddr_in *newcliaddr, char* name) {
	// 클라이언트의 아이피 저장 배열
	char ip[LEN];
	// 로그 저장 배열
	char logbuf[MAXLINE];
	// 클라이언트의 아이피를 ip버퍼에 저장한다.
	inet_ntop(AF_INET,&newcliaddr->sin_addr,ip,sizeof(ip));
	// 클라이언트 구조체에 소켓번호를 저장한다.
	clients[num_chat].socketNumber = s;
	// 클라이언트 구조체에 아이피, 접속시간, 이름을 저장한다.
	strcpy(clients[num_chat].ip, ip);
	strcpy(clients[num_chat].connectTime, getNowTime());
	strcpy(clients[num_chat].name, name);
	// 로그버퍼에 해당 내용을 쓴다.
	sprintf(logbuf, "[New client] Name : %s, IP : %s ", name, ip);
	// 버퍼에 로그버퍼의 내용을 복사하여 로그가 저장되게 한다.
	strcpy(buf, logbuf);
	// 참가자의 수를 1 늘린다.
	num_chat++;
	// 로그버퍼에 새로운 참가자가 들어왔음을 알리는 문구를 쓰고 클라이언트들에게 방송한다.
	sprintf(logbuf, "====== System : New client %s come to chat. Please welcome! ======", name);
	send2clients(num_chat, logbuf, strlen(logbuf));
}

// 채팅 탈퇴 처리
void removeClient(int s) {
	// 로그 저장 배열
	char logbuf[MAXLINE];
	// 탈퇴할 클라이언트의 소켓을 닫는다.
	close(clients[s].socketNumber);
	// 로그에 해당하는 내용을 logbuf에 쓴다.
	sprintf(logbuf, "[Remove client] Name : %s, IP : %s ", clients[s].name, clients[s].ip);
	// 그 내용을 버퍼에 써 준다.
	strcpy(buf, logbuf);

	// 로그버퍼에 클라이언트가 채팅을 나갔음을 알리는 문구를 쓰고 클라이언트들에게 방송한다.
	sprintf(logbuf, "====== System : Client %s leave a chat. ======", clients[s].name);
	send2clients(num_chat, logbuf, strlen(logbuf));

	// 클라이언트의 리스트를 갱신한다.
	if(s != num_chat-1) {
		// 삭제하려는 클라이언트의 내용을 남아있는 클라이언트로 덮어쓴다.
		clients[s].socketNumber = clients[num_chat-1].socketNumber;
		strcpy(clients[s].connectTime, clients[num_chat-1].connectTime);
		strcpy(clients[s].ip, clients[num_chat-1].ip);
		strcpy(clients[s].name, clients[num_chat-1].name);
	}
	// 참가자의 수를 줄인다.
	num_chat--;
}

// 최대 소켓번호 찾기
int getmax() {
	// Minimum 소켓번호는 가정 먼저 생성된 listen_sock
	int max = listen_sock;
	int i;
	// 클라이언트에 저장된 소켓번호를 탐색하며 max값을 찾아 저장한다.
	for (i=0; i < num_chat; i++)
		if (clients[i].socketNumber > max )
			max = clients[i].socketNumber;

	// 최대값 반환
	return max;
}

// listen 소켓 생성 및 listen
int  tcp_listen(int host, int port, int backlog) {
	// 생성된 소켓번호를 저장할 변수
	int sd;
	// 소켓 구조체
	struct sockaddr_in servaddr;

	// TCP 소켓을 연다. -1이면 에러가 발생하므로 종료한다.
	sd = socket(AF_INET, SOCK_STREAM, 0);
	if(sd == -1) {
		perror("socket fail");
		exit(1);
	}
	// servaddr 구조체의 내용 세팅
	bzero((char *)&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(host);
	servaddr.sin_port = htons(port);

	// 소켓을 사용할 수 있도록 바인딩한다.
	if (bind(sd , (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
		perror("bind fail");  exit(1);
	}
	// 클라이언트로부터 연결요청을 기다린다.
	listen(sd, backlog);

	// 생성된 소켓을 반환한다.
	return sd;
}

// 로그를 파일에 저장하는 함수.
void save(struct Log log) {
	// 로그파일을 a+ 모드로 연다.
	logFile = fopen(filename, "a+");
	// 전송시간에 붙어있는 개행문자를 널 문자로 바꾼다.
	log.sendTime[24] = '\0';
	// 전송시간과 메세지를 서버 로그에 출력한다.
	printf("< Log > %s %s\n", log.sendTime, log.message);
	// 파일에 로그를 쓴다. 전송시간 - [메세지의 길이] 메세지 내용 의 포맷이다.
	fprintf(logFile, "%s - [%d] %s\n", log.sendTime, log.length, log.message);
	// 파일을 닫는다.
	fclose(logFile);
}

// 클라이언트의 정보를 출력하는 함수다.
void printClients() {
	int i;

	printf("================================= Clients =================================\n");
	// 모든 클라이언트의 소켓번호, 이름, 아이피주소, 접속시간을 출력한다.
	for(i = 0; i < num_chat; i++)
		printf("[%d] Name : %s,  IP : %s, Connected time : %s", clients[i].socketNumber, clients[i].name, clients[i].ip, clients[i].connectTime);

	printf("===========================================================================\n");
}

// 클라이언트를 추방하는 함수다.
void deport(int client) {
	char* message = "You are deported.";
	// 로그 저장 배열
	char logbuf[MAXLINE];
	// 반복문 변수
	int i;

	// 추방할 클라이언트의 소켓을 찾는다.
	// 잘못된 입력은 없다고 가정한다.
	for(i = 0; i < num_chat; i++)
		if(clients[i].socketNumber == client) 
			break;

	send(clients[i].socketNumber, message, strlen(message), 0);
	close(clients[i].socketNumber);
	// 로그에 해당하는 내용을 logbuf에 쓴다.
	sprintf(logbuf, "[Deport client] Name : %s, IP : %s ", clients[i].name, clients[i].ip);
	// 그 내용을 버퍼에 써 준다.
	strcpy(buf, logbuf);

	// 로그버퍼에 클라이언트가 추방되었음을 알리는 문구를 쓰고 클라이언트들에게 방송한다.
	sprintf(logbuf, "====== System : Client %s deported. ======", clients[i].name);
	send2clients(num_chat, logbuf, strlen(logbuf));

	// 클라이언트의 리스트를 갱신한다.
	if(i != num_chat-1) {
		// 삭제하려는 클라이언트의 내용을 남아있는 클라이언트로 덮어쓴다.
		clients[i].socketNumber = clients[num_chat-1].socketNumber;
		strcpy(clients[i].connectTime, clients[num_chat-1].connectTime);
		strcpy(clients[i].ip, clients[num_chat-1].ip);
		strcpy(clients[i].name, clients[num_chat-1].name);
	}
	// 참가자의 수를 줄인다.
	num_chat--;
}

// help 커맨드 입력 시 출력되는 함수
void printHelp() {
	// 기능명 : 커맨드 순으로 출력한다.
	printf("================================= Help =================================\n");
	printf("Show Clients : -show\n");
	printf("Deprot client : -deport (after enter socket number of client.)\n");
	printf("Server finish : -finish\n");
	printf("========================================================================\n");
}

// 서버 종료를 위해 모든 소켓들을 닫아주는 작업을 하게 된다.
void finish() {
	// 반복문 변수
	int i;
	// 클라이언트에게 전송할 종료 메시지
	char* message = "Server finished";

	// 모든 클라이언트들에게 서버가 종료됨을 알리고 소켓을 닫는다.
	for(i = 0; i < num_chat; i++) {
		send(clients[i].socketNumber, message, strlen(message), 0);
		close(clients[i].socketNumber);
	}
	close(listen_sock);
	close(accp_sock);
	// 로그 내용을 버퍼에 써 준다.
	strcpy(buf, "[Server Finished] ");

	// 서버의 상태를 종료(0) 으로 만든다.
	serverState = 0;
}
