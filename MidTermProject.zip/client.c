//--------------------------------------------------------------
// 파일명 : client.c
// 기  능 : 서버에 접속한 후 키보드의 입력을 서버로 전달
//          서버로부터 오는 메시지를 화면에 출력
//          추방 또는 서버종료, exit 전송 시 클라이언트 종료
// 컴파일 : gcc -o client client.c
// 사용법 : ./client [IP] [PORT] [NAME] 
//          ex)./client 127.0.0.1 5123 JDY
//--------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <unistd.h>
#include <arpa/inet.h>

// 버퍼의 최대 크기
#define MAXLINE     1000
// 클라이언트 명의 최대 크기
#define NAME_LEN    20

char* EXIT_STRING= "exit";
char* DEPORT_MESSAGE = "You are deported.";
char* SERVER_FINISH = "Server finished";
// 소켓 생성 및 서버 연결, 생성된 소켓리턴
int tcp_connect(int af, char *servip, unsigned short port);
void errquit(char *mesg) { perror(mesg); exit(1); }

int main(int argc, char *argv[]) {
	// 이름+메시지를 위한 버퍼, bufall 에서 메시지부분의 포인터
	char bufall[MAXLINE+NAME_LEN], *bufmsg;
	// 최대 소켓 디스크립터, 소켓, 이름의 길이
	int maxfdp1, s,namelen;
	// 읽기를 감지할 fd_set 구조체
	fd_set read_fds;

	// 사용법이 잘못되었을 경우 사용법 출력 후 종료
	if(argc != 4) {
		printf("사용법 : ./client sever_ip port name \n");
		exit(0);
	}

	sprintf(bufall, "[%s] :", argv[3]); // bufall 의 앞부분에 이름을 저장
	namelen= strlen(bufall); // 이름의 길이를 저장
	bufmsg = bufall+namelen; // 메시지의 시작부분은 bufall의 위치에서 namelen 만큼 증가한 위치(주소값)

	// 서버의 아이피와 포트로 tcp 소켓을 얻는다.
	s = tcp_connect(AF_INET, argv[1], atoi(argv[2]));
	// 소켓을 얻지 못하는 경우 에러.
	if(s==-1)
		errquit("tcp_connect fail");

	// 서버에 접속 시 접속자의 이름을 서버에 보낸다.
	if (send(s, argv[3], strlen(argv[3]), 0) < 0)
		puts("Error : Write error on socket.");

	// 최대 fdp1은 소소켓번호 중 가장 큰 번호 +1 이다.
	maxfdp1 = s + 1;
	// read_fds의 모든 소켓을 0으로 초기화한다.
	FD_ZERO(&read_fds);

	// 접속을 끊지 않는 이상 무한 반복한다.
	while(1) {
		// 키보드 입력용 파일 디스크립터를 세팅한다.
		FD_SET(0, &read_fds);
		// 서버와 연결된 소켓번호를 세팅한다.
		FD_SET(s, &read_fds);

		// 소켓들에서 발생하는 I/O 를 감지한다.
		if(select(maxfdp1, &read_fds, NULL,NULL,NULL) < 0)
			errquit("select fail");

		// 소켓 s가 세트되어 있으면 메세지를 받는다.
		if (FD_ISSET(s, &read_fds)) {
			// 바이트 크기 저장 변수
			int nbyte;
			// 바이트의 크기가 0보다 커야 메세지를 받는 것이다.
			if ((nbyte = recv(s, bufmsg, MAXLINE, 0)) > 0)  {
				// bufmsg에 저장하고 마지막 위치에 널을 삽입한다.
				bufmsg[nbyte] = 0;

				// 추방 메시지 혹은 서버종료 메시지를 받으면 클라이언트를 종료한다.
				if(strstr(bufmsg, DEPORT_MESSAGE) != NULL || strstr(bufmsg, SERVER_FINISH) != NULL) {
					// 메시지를 출력한다.
					printf("====== System : %s ======  \n", bufmsg);
					// 소켓을 닫는다.
					close(s);
					exit(0);
				}
				// 그 외의 메시지는 채팅이므로 그냥 출력한다.
				else printf("%s \n", bufmsg);
			}
		}

		// 키보드 입력이 세트되어 있으면 메세지를 보낸다.
		if (FD_ISSET(0, &read_fds)) {
			// 키보드로부터 bufmsg에 메세지를 입력한다.
			if(fgets(bufmsg, MAXLINE, stdin)) {
				// 닉네임과 이름을 소켓에 전송한다.
				if (send(s, bufall, namelen+strlen(bufmsg), 0) < 0)
					puts("Error : Write error on socket.");

				// EXIT_STRING인 경우 연결을 끊는다.
				if (strstr(bufmsg, EXIT_STRING) != NULL ) {
					puts("Good bye.");
					close(s);
					exit(0);
				}
			}
		}
	} // end of while
}

// 연결 프로토콜, 서버의 아이피, 포트를 입력받아 TCP 소켓을 반환하는 함수
int tcp_connect(int af, char *servip, unsigned short port) {
	// 소켓 구조체를 선언한다.
	struct sockaddr_in servaddr;
	// 소켓을 저장할 변수를 선언한다.
	int  s;

	// TCP 소켓을 생성한다.
	// 소켓생성 실패시 -1을 반환한다.
	if ((s = socket(af, SOCK_STREAM, 0)) < 0)
		return -1;

	// 채팅 서버의 소켓주소 구조체 servaddr 초기화
	bzero((char *)&servaddr, sizeof(servaddr));
	servaddr.sin_family = af;
	inet_pton(AF_INET, servip, &servaddr.sin_addr);
	servaddr.sin_port = htons(port);

	// 소켓을 사용하여 서버에 접속요청을 한다. 실패 시 -1을 반환한다.
	if(connect(s, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
		return -1;

	// 생성된 소켓을 반환한다.
	return s;
}

